# directedanalysis.com — build brief

You are building the marketing hub for **Directed Analysis**, a personal-brand
publication by Eric Summers (Tableau Ambassador). This file is the source of
truth for design and copy. A finished visual reference lives at
`reference/design-demo.html` — open it in a browser first. Match its look,
motion, and structure. Where this file and the demo disagree, this file wins.

The owner is an ideas person, not a coder. Explain your choices briefly as you
go, keep the code readable, and do not add dependencies without saying why.

---

## 0. Non-negotiable rules

1. **No em-dashes anywhere in visible copy.** Not in JSX, not in alt text, not
   in comments that could get copy-pasted into the site. Use periods, commas,
   or restructure. This is a brand voice rule and it is absolute.
2. **Numbered markers appear in exactly one section: the five beats.** That is
   the only content that is a real sequence. Do not number anything else.
3. **One orchestrated motion only.** The hero plot animates once when it scrolls
   into view, and responds to its own toggle buttons. Nothing else fades,
   slides, or animates on scroll. Respect `prefers-reduced-motion`.
4. Ship the quality floor without announcing it: responsive to mobile, visible
   keyboard focus, reduced-motion respected, semantic HTML, good color contrast.

---

## 1. Stack

- **Vite + React** (function components, hooks). Single page.
- Plain CSS with a tokens file (`tokens.css` or CSS variables in `:root`). Do
  not pull in Tailwind or a component kit. The design is deliberately not
  card-kit SaaS and a utility framework will push it back toward that.
- Fonts: **Archivo** + **Archivo Expanded** (display/UI) and **Newsreader**
  (body/serif). Use `@fontsource/archivo`, `@fontsource/newsreader`, plus the
  Archivo Expanded axis, or the Google Fonts CDN link already in the demo head.
- **D3** is available and preferred for the plot if you drive it from data (see
  section 5). It is not required for anything else. Do not use it for layout.

Suggested structure:

```
src/
  main.jsx
  App.jsx
  tokens.css
  components/
    Header.jsx
    Hero.jsx
    Plot.jsx          <- the centerpiece, spend your care here
    Thesis.jsx
    Beats.jsx
    Quotes.jsx
    Pillars.jsx
    EssayCard.jsx
    Subscribe.jsx
    Footer.jsx
  content.js          <- all copy + data arrays live here, one source of truth
```

Put every copy string and data array in `content.js` so the owner can edit words
without touching components.

---

## 2. Design tokens

```css
:root{
  --ink:        #16202B;  /* text, deep prussian near-black */
  --paper:      #EDEAE1;  /* page background, cool bone */
  --paper-2:    #E5E1D6;  /* raised panels */
  --field:      #12202C;  /* the plot's dark field only */
  --brass:      #A9772A;  /* the single accent, gold not clay */
  --brass-lift: #D4A24A;  /* brass on the dark field */
  --muted:      #6B6357;  /* secondary text */
  --muted-lift: #9DA7AF;  /* secondary text on dark */
  --line:       #D7D1C4;  /* hairlines */
}
```

This palette is a choice, not a default. Do not drift it toward warm
cream + terracotta, and do not introduce a second accent color.

---

## 3. Type

- **Wordmark and h1 and section headings:** Archivo Expanded, 700–800,
  slightly negative letter-spacing on large sizes.
- **Body, about-line, thesis, pull-quotes, essay copy:** Newsreader serif, 400.
- **UI labels, buttons, eyebrows, axis ticks, tier names:** Archivo, 600.

The inversion is intentional: the serif is the reading voice, the sans is the
instrument panel. Do not accent a single word in a headline by italicizing or
recoloring it (the one deliberate exception is the brass second line of the
hero headline, which is already in the demo). Avoid all-caps except for short
UI labels like the wordmark and eyebrows.

Type scale is in the demo CSS; reuse those `clamp()` values.

---

## 4. Page structure (top to bottom)

1. **Header** (sticky, translucent). Wordmark with the small compass-bearing
   SVG on the left, a single "Subscribe" outline button on the right.
2. **Hero.** Two-line headline, one serif about-line, then the Plot.
3. **Thesis.** One large serif sentence, small "THE THESIS" label above it.
4. **The five beats.** The numbered sequence. Grid of number + line.
5. **Pull-quotes.** The load-bearing lines, one of them (the moat line) on an
   ink background.
6. **Pillars.** "What you'll read here," a quiet list with a small brass
   compass-diamond marker, no numbers.
7. **Essay card.** The Valuable Part. See section 6, it is launch-blocked.
8. **Subscribe.** The framing line plus the four tiers.
9. **Footer.** Eric Summers, Tableau Ambassador, plus the tagline.

---

## 5. The Plot (the centerpiece)

A single horizontal bar representing 100% of the analyst's week. It has two
states and animates between them. This is the whole thesis, shown wordlessly.

**Data model** (put in `content.js`):

```js
export const plotStates = {
  old: {
    segments: [
      { kind: 'think',    pct: 8,  label: 'Thinking' },
      { kind: 'assemble', pct: 84, label: 'Assembly' },
      { kind: 'think',    pct: 8,  label: 'Thinking' },
    ],
    needle: 50,   // percent position of the VALUE needle
    caption: "A week spent building. We called it analysis. <b>It wasn't.</b>",
  },
  now: {
    segments: [
      { kind: 'think',    pct: 44, label: 'Thinking' },
      { kind: 'assemble', pct: 12, label: 'Assembly' },
      { kind: 'think',    pct: 44, label: 'Thinking' },
    ],
    needle: 78,
    caption: "The building is nearly free now. <b>The week is thinking.</b>",
  },
};
```

**Behavior:**

- `think` segments are brass, `assemble` is a muted navy. A vertical brass
  "VALUE" needle sits over the bar and slides between states.
- Under the bar, a faint tick axis: 0, 25, 50, 75, 100% of the week.
- Two toggle buttons: "The old week" / "The week now" (aria-pressed reflects
  state). Below them a quiet note: "Same job. The value moved."
- On mount, render the `old` state. When the plot scrolls into view
  (IntersectionObserver, threshold ~0.4), wait ~900ms then transition to `now`,
  once. Buttons let the user replay either state.
- Segment width and needle position transition over ~1.15s with an ease like
  `cubic-bezier(.72,0,.16,1)`. Caption cross-fades.
- If a segment drops below ~10% width, hide its text label so it doesn't clip.
- `prefers-reduced-motion`: skip the auto-animation, render `now` immediately,
  keep the buttons working with no transition.

**Implementation note:** CSS width transitions driven by React state are enough
and are the simplest correct version. If you want D3 here (the owner likes it),
the honest place it earns its keep is when the abstract three-block bar becomes
a real five-phase week (framing, cleaning, joining, building, reading) with a
`d3.scaleLinear` mapping cumulative percent to x, and `d3` transitions on the
segments. Build the simple version first, leave a comment marking where the
data-driven D3 version would slot in. Do not over-engineer the first pass.

---

## 6. The essay card is launch-blocked

The "Read the essay" button must not resolve to a live essay yet. The
inaugural essay (The Valuable Part) was flagged as AI-generated and is being
rewritten in the owner's voice before it ships. For now:

- Render the card exactly as in the demo.
- Point the button at a `#` placeholder or a disabled state, and leave a code
  comment: essay pending voice pass, do not wire to live URL until cleared.

---

## 7. Copy (verbatim, em-dash free)

Use these strings exactly. They already obey the no-em-dash rule.

**Wordmark:** `DIRECTED ANALYSIS`

**Hero headline (two lines):**
- line 1: `We used to direct the tools.`
- line 2 (brass): `Now we direct the analysis.`

**About-line:**
`Building the chart got easy. The analysis is where the value went. Tool-agnostic notes for the analyst in the AI shift.`

**Thesis** (label `THE THESIS`):
`AI automated the assembly, not the analysis. The entire value of an analyst just moved into the thinking they were always told to rush past.`

**The five beats** (heading `The argument, in five beats`):
1. `The old job was mostly assembly, and we mistook the assembly for the job.`
2. `The machine got good at assembly. It is nearly free now.`
3. `So the value did not vanish. It moved, back to the thinking.`
4. `Directing requires understanding, so the skill bar rose. You cannot fake it anymore.`
5. `So put your time and your learning into the analysis. It is the valuable part, and now you finally can.`

**Pull-quotes** (bold the fragment shown in `<b>`):
- `Viz is the easy part. <b>Analysis is the valuable part.</b>`
- `The assembly is free. <b>The thinking is in full view.</b>`
- (moat, on ink) `You can't direct <b>what you don't understand.</b>`
- (wide) `The thing you spend your time on is finally the thing that's actually valuable.`

**Pillars** (heading `What you'll read here`):
- `How I think through a project before I touch anything.`
- `How I decide what is worth building and what to throw out.`
- `How I work with the person who asked, so I answer the real question.`
- `How I direct a build. What I pay for, and what I refuse to.`
- `Where your time should go now that the assembly is cheap.`
- `Worked examples. Real analytics I have directed, with the reasoning left in.`

**Essay card:**
- eyebrow: `THE INAUGURAL ESSAY`
- title: `The Valuable Part`
- sub: `The confession, the reframe, and the moat. Why the automation you were told to fear came for the assembly, not the thinking.`
- button: `Read the essay`

**Subscribe** (heading `Subscribe`):
- framing: `Every essay stays free, in full, always. Paid does not buy the writing. It buys support, the community, and my time.`
- tiers:
  - `FREE` / `$0` / `Every essay, in full, in your inbox. Always.`
  - `SUPPORTER` / `$8 / mo` / `Keeps it independent and ad-free. Full comments and the subscriber chat.`
  - `ANNUAL` / `$80 / yr` / `Everything in Supporter, plus one 30-minute strategy session with me each year.`
  - `FOUNDING ANALYST` / `$200 / yr` / (feature, on ink) `Everything, plus direct access and a standing invite to office hours. In your corner.`

**Footer:**
- `Eric Summers` + `· Tableau Ambassador`
- tagline (italic): `We used to direct the tools. Now we direct the analysis.`

---

## 8. Subscribe wiring

The tiers mirror the Substack architecture (free / $8 / $80 / $200 Founding
Analyst). For now the tier block is presentational. When ready, the buttons
link out to the Substack subscribe URLs. Do not build a payment flow here.
Leave the subscribe destinations as a single config value in `content.js`
(e.g. `SUBSCRIBE_URL`) so it is one edit later.

---

## 9. Acceptance checklist

- [ ] Renders and matches `reference/design-demo.html` in look and motion.
- [ ] Zero em-dashes in any visible string.
- [ ] Numbers appear only in the five beats.
- [ ] Plot animates once on scroll-in, toggles work, reduced-motion respected.
- [ ] Fully responsive down to ~360px. Tiers and quotes reflow, plot stays legible.
- [ ] Keyboard focus visible on the two buttons, the subscribe button, and links.
- [ ] All copy and data sit in `content.js`.
- [ ] Essay button is not wired to a live URL.
- [ ] No unexplained dependencies added.
