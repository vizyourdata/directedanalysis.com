# Directed Analysis — site package

This folder is a handoff for building **directedanalysis.com** in a Claude Code
session.

## What's here

- **CLAUDE.md** — the build brief. Claude Code loads this automatically as
  project context. It has the design tokens, type, full copy, the plot spec,
  and an acceptance checklist. This is the source of truth.
- **reference/design-demo.html** — the finished visual demo. Open it in a
  browser to see the target: colors, motion, structure. Self-contained, no
  build step.

## How to use it

1. Drop this whole folder into your project root
   (`...\Directed Analysis\directedanalysis.com\`).
2. Open the folder in VS Code and start a Claude Code session in it.
3. Tell Claude Code: scaffold a Vite + React app in this folder and build the
   site per CLAUDE.md, using reference/design-demo.html as the visual target.
4. Review as it goes. It will keep copy and data in `src/content.js` so you can
   edit words without touching code.

## The architecture decision this assumes

directedanalysis.com (this React hub) is the front door. Substack is the
reading and subscription engine behind it, at a subdomain or linked out. The
site's subscribe tiers point to Substack when you wire them up.

## Two things deliberately left unfinished

- The **"Read the essay"** button goes nowhere on purpose. The inaugural essay
  is being rewritten in your voice first. Do not point it at a live URL until
  that clears.
- The **subscribe** buttons are presentational until you drop in the Substack
  URLs (one config value in content.js).
